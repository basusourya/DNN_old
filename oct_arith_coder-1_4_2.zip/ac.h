#ifndef AC_HEADER
#define AC_HEADER

#include <stdio.h>
#define AC_USE_MULTISTREAM
typedef struct {
  unsigned char *mem;
  long size;
  long pos;
  int allocated;
} buffer;

typedef struct {
  FILE *file;
  buffer *buf;
  int reading;
  int to_mem;
} STREAM; 

typedef struct {
#ifdef AC_USE_MULTISTREAM
  STREAM *fp;
#else
  FILE *fp;
#endif
  long low;
  long high;
  long fbits;
  int buffer;
  int bits_to_go;
  long total_bits;
} ac_encoder;

typedef struct {
#ifdef AC_USE_MULTISTREAM
  STREAM *fp;
#else
  FILE *fp;
#endif
  long value;
  long low;
  long high;
  int buffer;
  int bits_to_go;
  int garbage_bits;
} ac_decoder;

typedef struct {
  int nsym;    /* Alphabet size */
  int *freq;   /* Symbol probability */
  int *cfreq;  /* Cumulative frequency cfreq[i]=sum(n>=i) freq[n] */
  int adapt;   /* Be adaptive */
} ac_model;

int  ac_encoder_init (ac_encoder *, const char *, const char *);
void ac_encoder_done (ac_encoder *ace, char **addr, long *size);
int  ac_decoder_init (ac_decoder *, const char *, long skip, int from_mem);
void ac_decoder_done (ac_decoder *);
int  ac_model_init (ac_model *, int, int *, int);
void ac_model_done (ac_model *);
long ac_encoder_bits (ac_encoder *);
int  ac_encode_symbol (ac_encoder *, ac_model *, int);
int  ac_decode_symbol (ac_decoder *, ac_model *);

int  ac_get_encoder_buffer(ac_encoder *ace, char **addr, long *size);

unsigned int maximum_alphabet_size();

#endif
