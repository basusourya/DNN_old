function arith_encode(h, data)
% ARITH_ENCODE           Encode with an arithmetic encoder
%
%      Synopsys:
%
%            ARITH_ENCODE(ENCODER, DATA)
%
%      Parameters:
%
%           ENCODER = Handler of an arithmetic encoder created with 
%           NEW_ARITHMETIC_ENCODER
%  
%           DATA = Array of NON-NEGATIVE INTEGER values smaller
%           than the parameter AB_SIZE given to
%           NEW_ARITHMETIC_ENCODER.
%
%      Description:
%
%           DATA is forced to a column vector and its entries are
%           rounded to the nearest integer.  The value in data are
%           encoded by means of the arithmetic encoder created with
%           NEW_ARITHMETIC_ENCODER.
%
%      Defaults:
%
%           NONE
%
%      See also: 
%
%           NEW_ARITHMETIC_ENCODER
%

%%
%% Default handling
%%

%
% Call parsing
%

%
% Default values
%

if (~isfield(h, 'encoder') || ~h.encoder)
  error('Not an encoder');
end

%%
%% True code
%%

data = data(:);
data_int = round(data);

if (max(abs(data-data_int)) > 1e-5)
  warning(['Max difference between data and its rounded version >' ...
	   ' 1e-5']);
end

if (any(data_int < 0) || any(data_int > h.ab_size-1))
  msg='Values in DATA out of range 0..%d';
  error(msg, h.ab_size-1);
end

arith__coder__gateway('encode', h.handler, data_int);
