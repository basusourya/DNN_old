function test_arith_library
%
% Little script to test the functions of the arithmetic 
% enc/decoder library
%
N = [16, 64, 128, 1024];
sz = {[12, 14], [5, 4, 9], [1 128]};
filename = tempname;

disp('File I/O tests:')
passati = 0;

for n=1:length(N)
  for k=1:length(sz)
    x = fix(N(n)*randn(sz{k}));
    save_arith_compressed(x, filename);
    u = load_arith_compressed(filename);
    if (all(all(u==x)))
      passati = passati+1;
    end
  end
end

test_data=load('test_data');
x=test_data.x;
save_arith_compressed(x, filename);
u = load_arith_compressed(filename);
if (all(all(u==x)))
  passati = passati+1;
end

totali = length(N)*length(sz) + 1;
disp(sprintf('  Passed %3d tests out of %3d', passati, totali))
disp(sprintf('  Failed %3d tests out of %3d', totali-passati, totali))


disp('Memory I/O tests:')
passati=0;

for n=1:length(N)
  for k=1:length(sz)
    x = floor(N(n)*rand(sz{k}));
    x = x(:); 
    h=new_arithmetic_encoder(N(n)+1);
    arith_encode(h, x);
    u=arith_close(h);
    h=new_arithmetic_decoder(u);
    u=arith_decode(h, length(x));

    if (all(all(u==x)))
      passati = passati+1;
    end
  end
end

x=test_data.x;
save_arith_compressed(x, filename);
u = load_arith_compressed(filename);
if (all(all(u==x)))
  passati = passati+1;
end

totali = length(N)*length(sz)+1;
disp(sprintf('  Passed %3d tests out of %3d', passati, totali))
disp(sprintf('  Failed %3d tests out of %3d', totali-passati, totali))

