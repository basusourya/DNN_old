function arith__cleanup()
% ARITH__CLEANUP   Called at exit time to perform cleanups

arith_coder_mex('cleanup');
