function y=load_arith_compressed(filename, skip)
% LOAD_COMPRESSED           Load a matrix saved by SAVE_ARITH_COMPRESSED
%
%      Synopsys:
%
%            Y=LOAD_ARITH_COMPRESSED(FILENAME)
%
%            Y=LOAD_ARITH_COMPRESSED(FILENAME, SKIP)
%
%      Parameters:
%
%           VOID
%
%      Description:
%
%           Load from FILENAME a matrix previously saved with
%           SAVE_ARITH_COMPRESSED.   If SKIP is given, skip the
%           first SKIP bytes of FILENAME.
%
%      Defaults:
%
%           SKIP = 0
%
%      See also: 
%
%           SAVE_ARITH_COMPRESSED
%

%%
%% Default handling
%%

%
% Call parsing
%

if (nargin < 2)
  skip = [];
end

%
% Default values
%

if (isempty(skip))
  skip=0;
end

%%
%% True code
%%

%
% Apri il file di ingresso.  Si noti il terzo parametro che
% richiede di salvare gli interi nel formato Big Endian (questo
% permette di portare i file salvati da un'architettura all'altra)
%
[fid,msg] = fopen(filename, 'rb', 'ieee-be');
if (fid < 0)
  error(['Could not open ' filename ' in input: ' msg]);
end

if (skip > 0)
  if (fseek(fid, skip, 'bof') < 0)
    fclose(fid);
    error(['Unable to seek: ' ferror(fid)]);
  end
end

%
% Comincia a leggere il file.  Vedi commenti in
% save_arith_compressed per una descrizione dettagliata del
% formato. 
%
flags = fread(fid, 1, 'uint8');

flag_ndim = rem(flags, 2);    % Estrai il bit 0 di flags 
flags = fix(flags/2);         % Trasla a destra di 1 posizione

flag_dims = rem(flags, 4);    % Estrai i bit 1 e 2 di flags
flags = fix(flags/4);         % Trasla a destra di 2 posizioni

flag_ab_size = rem(flags, 2); % Estrai il bit 3 di flags
flags = fix(flags/2);         % Trasla a destra di 1 posizione

flag_k0 = rem(flags, 2);      % Estrai il bit 4 di flags
flags = fix(flags/2);         % Trasla a destra di 1 posizione

%
% Se flag_ndim � falso, il prossimo byte � il numero di dimensioni
% della matrice salvata, altrimenti il numero di dimensioni � pari
% a due.
%
if (flag_ndim)
  n_dimension = fread(fid, 1, 'uint8');
else
  n_dimension = 2;
end

%
% Leggi le dimensioni della matrice salvata
%
dimen   = read_vec(fid, flag_dims, [1 n_dimension]);

%
% Leggi il numero di elementi dell'alfabeto
%
ab_size = read_vec(fid, flag_ab_size, [1 1]);

%
% Se flag_k0 � vero, i dati salvati sono stati traslati di k0 in
% modo da renderli tutti positivi ed il valore di k0 � contenuto
% nei prossimi due byte. 
%
if (flag_k0)
  k0 = fread(fid, 1, 'int16');
else
  k0 = 0;
end

%
% Leggi la posizione attuale del file e chiudi il file di
% ingresso.  Il file verr� riaperto dalla funzione
% new_arithmetic_decoder() pi� sotto
%
skip = ftell(fid);
fclose(fid);

%
% Chiama new_arithmetic_decoder() passandogli il parametro skip in
% modo da saltare l'header.
%
h=new_arithmetic_decoder(filename, ab_size, skip);

%
% Decodifica i dati contenuti nel file e somma k0 in modo da
% compensare la traslazione iniziale
%
y = arith_decode(h, dimen)+k0;
arith_close(h);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y=read_vec(fid, flag, how_many)

if (flag==0)
  fmt = 'uint8';
elseif (flag==1)
  fmt = 'uint16';
elseif (flag==2)  
  fmt = 'uint32';
else
  error('boh');
end


y = fread(fid, how_many, fmt);
