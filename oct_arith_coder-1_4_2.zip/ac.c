#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ac.h"

#define Code_value_bits 16

#define Top_value (((long)1<<Code_value_bits)-1)
#define First_qtr (Top_value/4+1)
#define Half	  (2*First_qtr)
#define Third_qtr (3*First_qtr)
#define Max_frequency 16383

void error(char *);  /* Defined in arith_coder_mex.c */

#define check(b,m)   do  { if (b) error(m); }  while (0)

/* 
   #define calloc internal_calloc
   void *internal_calloc(size_t nmemb, size_t size);
*/

static void output_bit (ac_encoder *, int);
static void bit_plus_follow (ac_encoder *, int);
static int input_bit (ac_decoder *);
static void update_model (ac_model *, int);

/*
 *#define error(m)                                           \
 *do  {                                                      \
 *  fflush (stdout);                                         \
 *  fprintf (stderr, "%s:%d: error: ", __FILE__, __LINE__);  \
 *  fprintf (stderr, m);                                     \
 *  fprintf (stderr, "\n");                                  \
 *  exit (1);                                                \
 *}  while (0)
 */

/*
 * #define AC_USE_MATLAB_ALLOC_NO
 * #ifdef AC_USE_MATLAB_ALLOC
 * #  define malloc mxMalloc
 * #  define calloc mxCalloc
 * #  define free   mxFree
 * #endif
 */

#ifndef AC_USE_MULTISTREAM
#  define stream_putc    putc
#  define stream_getc    getc
#  define stream_seek    fseek
#  define stream_open    fopen
#  define stream_close   fclose
#else

unsigned int
maximum_alphabet_size()
{ return Max_frequency/2; }

static buffer *
new_buffer(const char *addr, long size)
{
  buffer *result=(buffer*) malloc(sizeof(buffer));
  check(!result, "buffer allocation failure");

  result->mem = (char *)malloc(size);
  check(!result->mem, "buffer allocation failure");

  if (addr != NULL)
    {
      memcpy(result->mem, addr, size);
    }


  result->size = size;
  result->pos=0;

  /* printf("Buffer size=%d, pos=%d\n", result->size, result->pos); */
  return result;
}

static void 
delete_buffer(buffer *pt)
{
  if(pt->allocated)
    free(pt->mem);

  free(pt);
}

static int
buffer_put(int c, buffer *pt)
{
  unsigned char to_write = (unsigned char)c;
  if (pt->pos == pt->size)
    {
      int Delta = 1024;

      pt->mem = realloc(pt->mem, pt->size+Delta);
      check(!pt->mem, "buffer allocation failure");
      pt->size += Delta;
    }

  pt->mem[pt->pos]= to_write;
  pt->pos++;

  return (int) to_write;
}

static int
buffer_get(buffer *pt)
{
  if (pt->pos == pt->size)
    return 0;
  else
    return (int) pt->mem[pt->pos++];
}

static int 
buffer_seek(buffer *pt, long offset, int origin)
{
  switch(origin)
    {
    case SEEK_SET:
      break;
    case SEEK_CUR:
      offset += pt->pos;
      break;
    case SEEK_END:
      offset = pt->size-offset;
      break;
    }

  pt->pos = (offset < pt->size) ? offset :  pt->size;
  return 0;
}

static void
buffer_export(buffer *pt, char **addr, long *sz)
{
  *sz=pt->pos;
  *addr=(char*)malloc(sizeof(char)*(*sz));
  memcpy(*addr, pt->mem, *sz);
}

static int
stream_putc(int c, STREAM *fp)
{ 
  if (fp->to_mem)
    return buffer_put(c, fp->buf);
  else
    return fputc(c, fp->file);
}

static int
stream_getc(STREAM *fp)
{ 
  if (fp->to_mem)
    return buffer_get(fp->buf);
  else
    return getc(fp->file);
}

static STREAM *
output_memory_stream()
{
  STREAM *result = (STREAM*) malloc(sizeof(STREAM));
  check(!result, "stream allocation failure");

  result->file = NULL;
  result->buf = new_buffer(NULL, 0);
  result->reading = 0;
  result->to_mem = 1;

  return result;
}

static STREAM *
input_memory_stream(const char *addr, long sz)
{ 
  STREAM *result = (STREAM*) malloc(sizeof(STREAM));
  check(!result, "stream allocation failure");

  result->file = NULL;
  result->buf = new_buffer(addr, sz);
  result->reading = 1;
  result->to_mem = 1;

  return result;
}

static STREAM *
file_stream(const char *name, const char *mode)
{ 
  STREAM *result = (STREAM*) malloc(sizeof(STREAM));
  check(!result, "stream allocation failure");

  result->buf = NULL;
  result->to_mem = 0;
  result->file = fopen(name, mode);
  check(!result->file, "Could not open file");

  return result;
}

static void 
stream_close(STREAM *fp)
{ 
  if (fp->to_mem)
    delete_buffer(fp->buf);
  else
    fclose(fp->file);
}

static int 
stream_seek(STREAM *fp, long offset, int pos)
{ 
  if (fp->to_mem)
    return buffer_seek(fp->buf, offset, pos);
  else
    return fseek(fp->file, offset, pos);
}
#endif


static void
output_bit (ac_encoder *ace, int bit)
{
  ace->buffer >>= 1;
  if (bit)
    ace->buffer |= 0x80;
  ace->bits_to_go -= 1;
  ace->total_bits += 1;
  if (ace->bits_to_go==0)  {
    stream_putc (ace->buffer, ace->fp);
    ace->bits_to_go = 8;
  }

  return;
}

static void
bit_plus_follow (ac_encoder *ace, int bit)
{
  output_bit (ace, bit);
  while (ace->fbits > 0)  {
    output_bit (ace, !bit);
    ace->fbits -= 1;
  }

  return;
}

static int
input_bit (ac_decoder *acd)
{
  int t;

  if (acd->bits_to_go==0)  {
    acd->buffer = stream_getc(acd->fp);
    if (acd->buffer==EOF)  {
      acd->garbage_bits += 1;
      if (acd->garbage_bits>Code_value_bits-2)
        error ("arithmetic decoder bad input file");
    }
    acd->bits_to_go = 8;
  }

  t = acd->buffer&1;
  acd->buffer >>= 1;
  acd->bits_to_go -= 1;

  return t;
}

static void
update_model (ac_model *acm, int sym)
{
  int i;

  if (acm->cfreq[0]==Max_frequency)  {
    /*
     * We reached the maximum value for 
     *
     *    acm->cfreq[0] = sum_n freq[n]
     *
     * scale all the values in freq[i] by 1/2 and 
     * update cfreq[]
     */
    int cum = 0;
    acm->cfreq[acm->nsym] = 0;
    for (i = acm->nsym-1; i>=0; i--)  {
      acm->freq[i] = (acm->freq[i] + 1) / 2;
      cum += acm->freq[i];
      acm->cfreq[i] = cum;
    }
  }

  /*
   * Now we can safely add 1 to freq[sym]
   */
  acm->freq[sym] += 1;
  for (i=sym; i>=0; i--)
    acm->cfreq[i] += 1;

  return;
}

int
ac_encoder_init (ac_encoder *ace, const char *fn, const char *mode)
{
  switch(mode[0])
    {
      /* Force binary mode */
    case 'w':
      mode = "wb";
      break;
    case 'a':
      mode = "ab";
      break;
    default:
      return -1;
    }

  if (fn)  {
    if (fn[0] == '\0')
      ace->fp = output_memory_stream();
    else
      ace->fp = file_stream (fn, mode); 

    check (!ace->fp, "arithmetic encoder could not open file");
  }  else  {
    ace->fp = NULL;
  }

  ace->bits_to_go = 8;

  ace->low = 0;
  ace->high = Top_value;
  ace->fbits = 0;
  ace->buffer = 0;

  ace->total_bits = 0;

  return 0;
}

int
ac_get_encoder_buffer(ac_encoder *ace, char **addr, long *size)
{
#ifndef AC_USE_MULTISTREAM
  *size=0;
#else
  if (! ace->fp->to_mem)
    *size = 0;
  else
    buffer_export(ace->fp->buf, addr, size);
#endif
}

void
ac_encoder_done (ac_encoder *ace, char **addr, long *size)
{
  ace->fbits += 1;
  if (ace->low < First_qtr)
    bit_plus_follow (ace, 0);
  else
    bit_plus_follow (ace, 1);
  if (ace->fp)
    stream_putc (ace->buffer >> ace->bits_to_go, ace->fp);

  ac_get_encoder_buffer(ace, addr, size);

  if (ace->fp)
    stream_close (ace->fp);

  return;
}

int
ac_decoder_init(ac_decoder *acd, const char *fn, long skip, int from_mem)
{
  int i;

  if (from_mem)
    acd->fp = input_memory_stream (fn, skip); 
  else
    acd->fp = file_stream (fn, "rb"); /* open in binary mode */

  check (!acd->fp, "arithmetic decoder could not open file");

  if (!from_mem && skip > 0)
    check(stream_seek(acd->fp, skip, SEEK_SET) < 0, "Unseekable stream");

  acd->bits_to_go = 0;
  acd->garbage_bits = 0;

  acd->value = 0;
  for (i=1; i<=Code_value_bits; i++)  {
    acd->value = 2*acd->value + input_bit(acd);
  }
  acd->low = 0;
  acd->high = Top_value;

  return 0;
}

void
ac_decoder_done (ac_decoder *acd)
{
  stream_close(acd->fp);

  return;
}

int
ac_model_init (ac_model *acm, int nsym, int *ifreq, int adapt)
{
  int i;

  /* Alphabet size */
  acm->nsym = nsym; 

  /* Symbol probability */
  acm->freq = (int *)  calloc (nsym, sizeof (int));
  check (!acm->freq, "arithmetic coder model allocation failure");

  /* Cumulative probability, i.e., 
   *
   *               cfreq[i] = sum(j>=i) freq[i] 
   *
   * Note that cfreq[nsym]=0 and that the "true" probability of 
   * symbol i is freq[i]/cfreq[0]
   */
  acm->cfreq = (int *)  calloc (nsym+1, sizeof (int));
  check (!acm->cfreq, "arithmetic coder model allocation failure");

  /* Is this coder adaptive? */
  acm->adapt = adapt;

  if (ifreq)  {
    /*
     *  ifreq != NULL.  Use probability in ifreq.
     */
    acm->cfreq[acm->nsym] = 0;
    for (i=acm->nsym-1; i>=0; i--)  {
      acm->freq[i] = ifreq[i];
      acm->cfreq[i] = acm->cfreq[i+1] + acm->freq[i];
    }
    if (acm->cfreq[0] > Max_frequency)
      error ("arithmetic coder model max frequency exceeded");
  }  else  {
    /*
     * ifreq == NULL.  Start with a uniform distribution
     */
    acm->cfreq[acm->nsym] = 0;
    for (i=0; i<acm->nsym; i++) {
      acm->freq[i] = 1;
      acm->cfreq[i] = acm->nsym - i;
    }
  }

  return 0;
}

void
ac_model_done (ac_model *acm)
{
  acm->nsym = 0;
  free (acm->freq);
  acm->freq = NULL;
  free (acm->cfreq);
  acm->cfreq = NULL;

  return;
}

long
ac_encoder_bits (ac_encoder *ace)
{
  return ace->total_bits;
}

int
ac_encode_symbol (ac_encoder *ace, ac_model *acm, int sym)
{
  long range;

  check (sym<0||sym>=acm->nsym, "symbol out of range");

  range = (long)(ace->high-ace->low)+1;
  ace->high = ace->low + (range*acm->cfreq[sym])/acm->cfreq[0]-1;
  ace->low = ace->low + (range*acm->cfreq[sym+1])/acm->cfreq[0];

  for (;;)  {
    if (ace->high<Half)  {
      bit_plus_follow (ace, 0);
    }  else if (ace->low>=Half)  {
      bit_plus_follow (ace, 1);
      ace->low -= Half;
      ace->high -= Half;
    }  else if (ace->low>=First_qtr && ace->high<Third_qtr)  {
      ace->fbits += 1;
      ace->low -= First_qtr;
      ace->high -= First_qtr;
    }  else
      break;
    ace->low = 2*ace->low;
    ace->high = 2*ace->high+1;
  }

  if (acm->adapt)
    update_model (acm, sym);

  return 0;
}

int
ac_decode_symbol (ac_decoder *acd, ac_model *acm)
{
  long range;
  int cum;
  int sym;

  range = (long)(acd->high-acd->low)+1;
  cum = (((long)(acd->value-acd->low)+1)*acm->cfreq[0]-1)/range;

  for (sym = 0; sym < acm->nsym && acm->cfreq[sym+1]>cum; sym++)
    /* do nothing */ ;

  if (sym==acm->nsym)
    {
      int n;

      printf("cum=%ld\n", cum);
      for(n=0; n<=acm->nsym; n++)
	printf("csym[%d]=%ld\n", n, acm->cfreq[n]);
    }

  check (sym >= acm->nsym, "symbol out of range");

  acd->high = acd->low + (range*acm->cfreq[sym])/acm->cfreq[0]-1;
  acd->low = acd->low +  (range*acm->cfreq[sym+1])/acm->cfreq[0];

  for (;;)  {
    if (acd->high < Half)  {
      /* do nothing */
    }  else if (acd->low >= Half)  {
      acd->value -= Half;
      acd->low   -= Half;
      acd->high  -= Half;
    }  else if (acd->low >= First_qtr && acd->high < Third_qtr)  {
      acd->value -= First_qtr;
      acd->low   -= First_qtr;
      acd->high  -= First_qtr;
    }  else {
      break;
    }

    acd->low   = 2*acd->low;
    acd->high  = 2*acd->high+1;
    acd->value = 2*acd->value + input_bit(acd);
  }

  if (acm->adapt)
    update_model (acm, sym);

  return sym;
}
