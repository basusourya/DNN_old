function y=arith__max_alphabet_size
% ARITH__MAX_ALPHABET_SIZE           Brief description
%
%      Synopsys:
%
%            Y=ARITH__MAX_ALPHABET_SIZE
%
%      Parameters:
%
%           VOID
%
%      Description:
%
%           NONE
%
%      Defaults:
%
%           NONE
%
%      See also: 
%
%           NONE
%

%%
%% Default handling
%%

%
% Call parsing
%

%
% Default values
%

%%
%% True code
%%

y=arith__coder__gateway('max_alphabet_size');
