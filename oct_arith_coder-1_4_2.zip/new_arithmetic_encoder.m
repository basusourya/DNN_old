function h=new_arithmetic_encoder(arg1, arg2, arg3)
% NEW_ARITH_ENCODER   Create a new arithmetic encoder
%
%      Synopsys:
%
%          Output to file:
%
%            H=NEW_ARITH_ENCODER(FILENAME, AB_SIZE, MODE)
%
%          Output to memory:
%
%            H=NEW_ARITH_ENCODER(AB_SIZE)
%
%      Parameters:
%
%           FILENAME = Output file
%           AB_SIZE  = Alphabet size
%           MODE     = Mode for fopen ('w' or 'a')
%
%      Description:
%
%           NONE
%
%      Defaults:
%
%           MODE = 'w'
%
%      See also: 
%
%           NONE
%

%%
%% Default handling
%%

%
% Call parsing
%

switch nargin
 case 1
  if (~isnumeric(arg1))
    error('Single parameter must be alphabet size');
  end
  
  filename = '';
  ab_size = arg1;
  to_mem = 1;
  mode = 'wb';
 case {2,3}
  filename = arg1;
  ab_size = arg2;
  to_mem = 0;
  if (nargin < 3)
    mode = 'wb';
  else
    mode = arg3;
  end
end

%
% Default values
%



%%
%% True code
%%

if (ab_size > arith__max_alphabet_size)
  error('Maximum alphabet size = %d < %d', arith__max_alphabet_size, ...
	ab_size);
end

%
% Controlla che MODE abbia un valore corretto: 'w', 'a', 'wb',
% 'ab', 'bw' o 'ba'
%

idx = find(mode == 'b');  %% Butta via un eventuale 'b'
mode(idx) = [];           %% 'b' e` assunto di default dal codice
                          %% in C.

%
% Qui MODE deve essere o 'w' o 'a'
%
if (length(mode) > 1 || (strcmp('w', mode)==0 && strcmp('a', mode)==0))
  error(['Wrong Mode ''' mode '''']);
end


h.handler=arith__coder__gateway(['new_encoder:', mode], filename, ab_size);
h.filename = filename;
h.encoder = 1;
h.open = 1; 
h.to_mem = to_mem;
h.ab_size = ab_size;



