/*
 * MEX file for using the arithmetic coder functions in ac.c.
 *
 * By R. Bernardini May 6, 2005
 */
#include "mex.h"

/* 
 * Octave includes the definitions of matrix.h in mex.h in order to 
 * avoid conflits with octave Matrix.h file in those architecture whose
 * filesystem is case-insensitive
 */
#ifndef IN_OCTAVE
#  include "matrix.h"
#endif 

#include "ac.h"
#include <string.h>
#include <setjmp.h>

#define VER "1.4.1 2008-05-16 (yyyy-mm-dd)"

#define calloc internal_calloc

void *internal_calloc(size_t nmemb, size_t size)
{
  void *result = mxCalloc(nmemb, size);

  if (result !=NULL)
    { mexMakeMemoryPersistent(result); }

  return result;
}

/*
 * Some system has rindex, some system has not.  Instead of trying to
 * guess at compile time if we can use rindex, I define my own 
 * rindex (with a different name).
 */
static 
char *find_last(char *s, int c)
{
  char *result=NULL;
  for( ; *s ; s++)
    if (*s==c) result=s;

  return result;
}

/*
 * Error-handling stuff.  When a function in ac.c detects an error, 
 * it calls the following function error() which copies the message 
 * into the buffer error_msg[] and jump back to mexFunction() via a 
 * longjmp().  Variable jump_buffer is initialized at the
 * beginning of mexFunction().
 */

static jmp_buf jump_buffer;
static char error_msg[512];

void error(char *msg)
{
  strncpy(error_msg, msg, sizeof(error_msg)/sizeof(char)-1);
  error_msg[sizeof(error_msg)/sizeof(char)-1]='\0';
  longjmp(jump_buffer, 1);
}


/*
 * In order to avoid the problem of passing pointers back to Matlab, we
 * use a static pool of encoder/decoder structures and pass back to
 * Matlab and index pointing into the pool.
 */

#define POOL_SIZE 512

typedef struct {
  ac_encoder encoder;      /* Structure for encoders */
  ac_decoder decoder;      /* Structure for decoders */
  ac_model   model;        /* Structure for stat models */
  enum {enc, dec} tipo;    /* If this entry is used for an enc/decoder */
  int busy;                /* If this entry is used or not */
} enc_decoder;

static enc_decoder encoder_pool[POOL_SIZE];

/*
 * Find the index of first unused enc/decoder in the pool and return
 * it.  If all the enc/decoders are used, return -1.
 */
static 
int get_free_handler()
{
  int idx;
  for (idx=0; idx<POOL_SIZE; idx++)
    {
      if (encoder_pool[idx].busy == 0)
	{
	  encoder_pool[idx].busy = 1;
	  return idx;
	}
    }

  return -1;
}

/*
 * Return back to the pool the enc/decoder with index h.
 */
void
static free_handler(int h)
{
  if (h < 0 || h >= POOL_SIZE)
    mexErrMsgTxt("Internal error: handler out of bounds");

  encoder_pool[h].busy = 0;
}

/*
 * Close an enc/decoder, that is, call the suitable "*_done" function
 * and return the handler back to the pool.
 */
static void
close_encoder(int handler, char **addr, long *size)
{
  *size=0;

  if (handler < 0 || handler >= POOL_SIZE)
    {
      char buf[1024];

      sprintf(buf, 
	      "Internal: handler '%d' out of bounds to close_encoder", 
	      handler);
      mexErrMsgTxt(buf);
    }

  if (encoder_pool[handler].busy == 0)
    return;

  if (encoder_pool[handler].tipo == enc)
    ac_encoder_done(&encoder_pool[handler].encoder, addr, size);
  else
    ac_decoder_done(&encoder_pool[handler].decoder);
  
  ac_model_done(&encoder_pool[handler].model);
  
  free_handler(handler);
}

static int
get_encoder_buffer(int handler, char **addr, long *size)
{
  if (encoder_pool[handler].busy == 0)
    return 0;

  if (encoder_pool[handler].tipo == dec)
    return 0;

  return ac_get_encoder_buffer(&encoder_pool[handler].encoder, addr, size);
}


/*
 * Convenience macros to convert matlab parameters to 
 * C data
 */
#define string_matlab2C(dst,src,msg)                     \
do {                                                     \
    if (!mxIsChar(src)) mexErrMsgTxt(msg);              \
    mxGetString(src, dst, sizeof(dst)/sizeof(char)-1);   \
} while (0)

#define para2string(dst, n)  \
do {\
  if (nrhs < ((n)+1))\
    mexErrMsgTxt("pochi parametri");\
  string_matlab2C(dst, prhs[n], "parametro non stringa");\
} while(0);

#define int_matlab2C(dst,src)                            \
do {                                                     \
    if (!mxIsNumeric(src)) mexErrMsgTxt("Atteso int");    \
    dst = (int) mxGetScalar(src);                        \
} while (0)

#define para2int(dst, n)  \
do {\
  if (nrhs < ((n)+1))\
    mexErrMsgTxt("pochi parametri");\
  int_matlab2C(dst, prhs[n]);\
} while(0);

/*
 * The first parameter of mexFunction() is a string which 
 * describes the requested action.  Since it is easier to 
 * work with integers than with strings we convert the first
 * parameter into an integer value which describes the requested
 * actions.  In order to do this easily, we keep the recognized
 * commands into a table.
 */
#define buf_SIZE 512

typedef struct {
  char *name;   /* Command name */
  int   code;   /* Associated integer */
} entry;

#define NEW_ENC     0
#define NEW_DEC     1
#define N_BITS      2
#define DONE        3
#define ENCODE      4
#define DECODE      5
#define VERSION     6
#define CLEANUP     7
#define MAX_AB_SIZE 8

#define CLOSE_ALL_HANDLER (-42)

static entry command_table[] = 
  { { "new_encoder",        NEW_ENC },
    { "new_decoder",        NEW_DEC },
    { "bits",               N_BITS },
    { "done",               DONE },
    { "encode",             ENCODE },
    { "decode",             DECODE },
    { "version",            VERSION },
    { "cleanup",            CLEANUP },
    { "max_alphabet_size",  MAX_AB_SIZE },
    { NULL, -1 } /* End of table entry */ 
  };


/*
 * Cleanup and initialization functions.
 */
void 
static cleanup()
{
  char *junk;
  long junk2;
  int idx;
  /* mexPrintf("Esco...\n");*/

  for (idx=0; idx<POOL_SIZE; idx++)
    close_encoder(idx, &junk, &junk2);
}

void
static initialize_mex()
{
  static int initialized=0;

  if (initialized) return;

#ifndef HAVE_OCTAVE
  mexAtExit(cleanup);
#endif

  initialized=1;
}

/*
 * Each command can have a list of options separated by ":". Function
 * parse_options(COM, OPT, MAX) accepts a pointer COM to the command
 * and returns in vector OPT the pointers to the found options. MAX is
 * the number of elements of  OPT.  For example, if
 * COM="ccc:a:b=42:x", then 
 *
 *    OPT[0]="a"
 *    OPT[1]="b=42"
 *    OPT[2]="x"
 *    OPT[3]=NULL
 *    OPT[4]=NULL
 *     :
 *     :
 *    OPT[MAX-1]=NULL
 */

static
void parse_options(char *command, char **options, int maxopt)
{
  int n;
  char *pt; 
  for (n=0; n<maxopt; n++)
    options[n] = NULL;

  for(n=0; n<maxopt-1 && (pt=find_last(command, ':'))!=NULL ; n++)
    {
      /* mexPrintf("trovato ':' %s\n", pt+1); */
      options[n] = pt+1;
      *pt = '\0';
    }
}

static
char *search_option(char **options, char *opt)
{
  int n=strlen(opt);
  for( ; *options != NULL && strncmp(*options, opt, n) != 0 ; options++)
    {}

  
  /* mexPrintf("Opzione '%s' trovata? %d\n", opt, result); */

  return *options;
}

/*
 * ...and finally... the "main" function.
 */

#define MAX_OPT 16

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{
  char command_s[buf_SIZE];
  char filename[512];
  char *options[MAX_OPT];

  int maxval;
  int idx;
  int command_code;
  int handler;
  int nsymbols;
  double *symbols;

  double symbols_farlocco[1024];

  int result=0;
  int err_code;

  enum { return_symbols, return_result, already_done } to_be_returned=return_result;

  initialize_mex();

  /*
   * Set the non-local jump buffer
   */
  if ((err_code=setjmp(jump_buffer)) != 0)
    {
      /* I arrive here when error() above longjmp()'s */

      mexErrMsgTxt(error_msg);
    }

  /*
   * Riconosci il tipo di azione richiesta
   */
  para2string(command_s, 0);

  parse_options(command_s, options, MAX_OPT);
  
  for(idx = 0; command_table[idx].name != NULL; idx++)
    { if (strcmp(command_s, command_table[idx].name)==0) break; }

  if (command_table[idx].code < 0)
	mexErrMsgTxt("Unrecognized command");

  command_code = command_table[idx].code;

  if (command_code == VERSION)
    {
      plhs[0] = mxCreateString(VER);
      return;
    }

  /*
   * Analizza il resto dei parametri sulla base dell'azione richiesta
   */
  if (command_code == NEW_ENC || command_code == NEW_DEC)
    {
      /*
       * We expect the name of the I/O file and the alphabet size.
       */
      para2string(filename, 1);
      para2int(maxval, 2);
    }
  else if (command_code != CLEANUP && command_code != MAX_AB_SIZE)
    {
      /*
       * For any action != NEW_*, CLEANUP and MAX_AB_SIZE, the first 
       * parameter must be a valid enc/decoder handler
       */

      para2int(handler, 1);
      if ((handler < 0 && 
	   ! (handler == CLOSE_ALL_HANDLER || command_code==DONE))
	  || handler >= POOL_SIZE 
	  || encoder_pool[handler].busy == 0)
	{
	  mexErrMsgTxt("invalid handler");
	}

      if (command_code == ENCODE)
	{
	  /*
	   * The "ENCODE" command requires a vector of symbols 
	   * to be encoded 
	   */
	  if (encoder_pool[handler].tipo != enc)
	    mexErrMsgTxt("Called ENCODE with a decoder handler"); 

	  if (nrhs < 3)
	    mexErrMsgTxt("Pochi parametri");
	  
	  nsymbols = mxGetNumberOfElements(prhs[2]);
	  symbols  = mxGetPr(prhs[2]);
	}
      else if (command_code == DECODE)
	{
	  /*
	   * The "DECODE" command accept, as optional parameter, the 
	   * number of symbols to be decoded.
	   */
	  if (encoder_pool[handler].tipo != dec)
	    mexErrMsgTxt("Called DECODE with an encoder handler"); 

	  if (nrhs < 3)
	    nsymbols = 1;
	  else
	    para2int(nsymbols, 2);

	  plhs[0] = mxCreateDoubleMatrix(1, nsymbols, mxREAL);
	  symbols = mxGetPr(plhs[0]);
	  to_be_returned = already_done;
	}
      
    }

  /*
   * Esegui l'azione
   */
  switch(command_code)
    {
    case MAX_AB_SIZE:
      result = maximum_alphabet_size();
      to_be_returned = return_result;
      break;
    case CLEANUP:
      cleanup();
      return;
    case NEW_ENC:
    case NEW_DEC:
      handler = get_free_handler();
      if (handler < 0) 
	{
	  result = -1;
	  break;
	}

      ac_model_init(&encoder_pool[handler].model, maxval, NULL, 1);

      if (command_code == NEW_ENC)
	{
	  char *mode;

	  encoder_pool[handler].tipo = enc;

	  mode = "w";
	  if (search_option(options, "a") != NULL)
	    mode = "a";

	  if (search_option(options, ">") != NULL)
	    mode = ">";


	  if (ac_encoder_init(&encoder_pool[handler].encoder, filename, mode) < 0)
	    {
	      ac_model_done(&encoder_pool[handler].model);
	      free_handler(handler);
	      handler = -1;
	    }
	}
      else
	{
	  /* Case command == NEW_DEC */

	  int ok; 

	  encoder_pool[handler].tipo = dec;


	  if (filename[0] != '\0')
	    {
	      /*
	       * filename is not empty: read from disk file
	       */

	      int skip=0;
	      char *pt=search_option(options, "s=");

	      if (pt != NULL)
		skip = atoi(pt+2);

	      ok=ac_decoder_init(&encoder_pool[handler].decoder, filename, skip, 0);

	    }
	  else
	    {
	      /*
	       * filename is empty: read from memory buffer
	       */

	      long n;

	      if (nrhs < 4)
		mexErrMsgTxt("Pochi parametri");
	  
	      nsymbols = mxGetNumberOfElements(prhs[3]);
	      symbols  = mxGetPr(prhs[3]);

	      {
		char *buf = malloc(nsymbols);

		for (n=0; n<nsymbols; n++)
		  buf[n] = (char) symbols[n];
		
		ok = ac_decoder_init(&encoder_pool[handler].decoder, 
				     buf, nsymbols, 1);

		free(buf);
	      }
	    }

	  if (ok < 0)
	    {
	      ac_model_done(&encoder_pool[handler].model);
	      free_handler(handler);
	      handler = -1;
	    }
	}

      result = handler;
      break;
    case DONE:
      {
	char *buf_addr=NULL;
	long buf_size=0;
	long n;

	if (handler == CLOSE_ALL_HANDLER)
	  {
	    for(n=0; n<POOL_SIZE; n++)
	      close_encoder(n, &buf_addr, &buf_size);
	  }
	else
	  {
	    close_encoder(handler, &buf_addr, &buf_size);
	    if (buf_size > 0)
	      {
		nsymbols = buf_size;
		plhs[0] = mxCreateDoubleMatrix(1, nsymbols, mxREAL);

		/* 
		 * symbols = (double*) mxCalloc(buf_size, sizeof(double));
		 */
		
		for(n=0; n<buf_size; n++)
		  *(mxGetPr(plhs[0])+n) = buf_addr[n];
		
		to_be_returned = already_done;
	      }
	  }
      }

      result = 0;
      break;
    case ENCODE:
      for (idx = 0; idx < nsymbols; idx ++)
	{
	  ac_encode_symbol(&encoder_pool[handler].encoder, 
			   &encoder_pool[handler].model,  
			   (int) symbols[idx]);
	}

      result = 0;
      break;
    case DECODE:

      for(idx=0; idx < nsymbols; idx++)
	{
	  symbols[idx] = ac_decode_symbol(&encoder_pool[handler].decoder, 
					  &encoder_pool[handler].model);
	  
	}

      to_be_returned = already_done;
      break;
    case N_BITS:
      if (encoder_pool[handler].tipo != enc)
	mexErrMsgTxt("Cannot use action 'n_bits' with decoders");

      result = ac_encoder_bits(&encoder_pool[handler].encoder);
      break;
    }


  /*
   * Assign the output value.  If the action was "DECODE" we return 
   * a row vector of symbols, otherwise we return the value in "result".
   */
  switch(to_be_returned)
    {
    case return_symbols:
      mexErrMsgTxt("Questo non dovrebbe accadere");

      /*
	plhs[0] = mxCreateDoubleMatrix(1, nsymbols, mxREAL);
	{
	int k;


	for (k=0; k<nsymbols; k++)
	  *(mxGetPr(plhs[0])+k) = symbols_farlocco[k];
      }

      */
      break;
    case return_result:
      plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
      *mxGetPr(plhs[0]) = result;

      break;
    case already_done:
      /* Nothing */
      break;
    }

}
