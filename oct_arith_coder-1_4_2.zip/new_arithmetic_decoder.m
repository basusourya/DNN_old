function h=new_arithmetic_decoder(arg1, arg2, arg3)
% NEW_ARITHMETIC_DECODER           Create a new arithmetic decoder
%
%      Synopsys:
%
%        Read from file:
%
%            H=NEW_ARITHMETIC_DECODER(FILENAME, AB_SIZE, [SKIP])
%
%        Read from memory:
%
%            H=NEW_ARITHMETIC_DECODER(BUFFER, AB_SIZE)
%            H=NEW_ARITHMETIC_DECODER(BINDATA)
%
%      Parameters:
%
%           FILENAME  = Input file
%           AB_SIZE   = Alphabet size
%           SKIP      = Number of bytes to skip before decoding
%           BUFFER    = Array of integers in the range [-128, 127]
%           BINDATA   = The struct returned by ARITH_CLOSE
%
%
%      Description:
%
%           NONE
%
%      Defaults:
%
%           SKIP = 0
%
%      See also: 
%
%           ARITH_CLOSE
%

%%
%% Default handling
%%

%
% Call parsing
%

switch nargin
 case 1
  %
  % The parameter is the struct returned by ARITH_CLOSE when
  % closing a to-memory encoder.
  %
  if (~isfield(arg1,'buffer') || ~isfield(arg1, 'ab_size'))
    error('The parameter should be a struct')
  end
  filename='';
  buf=arg1.buffer;
  ab_size=arg1.ab_size;
  skip = 0;
 case 2
  %
  % In this case we can have (FILENAME, AB_SIZE) or 
  % (BUFFER, AB_SIZE).
  %
  if (~arith__is_ab_size(arg2))
    error(['With two parameters, the second one must be a valid' ...
	   ' alphabet size']);
  end
  
  switch (class(arg1))
   case 'char'
    %
    % First parameter is FILENAME
    %
    filename = arg1;
    ab_size = arg2;
    buf = [];
   case 'double'
    %
    % First parameter is BUFFER
    %
    filename = '';
    buf = arg1;
    ab_size = arg2;
   otherwise
    error(['With two parameters, the first one must be a FILENAME or' ...
	   ' a vector']);
  end
  
  skip = 0;
 case 3
  %
  % Here we have (FILENAME, N_SYMBOLS, SKIP).  The first parameter
  % must be a string.
  %
  if (~ ischar(arg1))
    error('With three parameters, the first one must be a FILENAME');
  end
  
  if (~arith__is_ab_size(arg2))
    error(['With three parameters, the second one must be a valid' ...
	   ' alphabet size']);
  end

  if (~(arg3==0 || arith__is_ab_size(arg3)))
    error(['With three parameters, the third one must be a ' ...
	   ' non-negative integer']);
  end

  
  filename = arg1;
  ab_size  = arg2;
  skip     = arg3;
  buf = [];
end



%
% Default values
%

%%
%% True code
%%

if (ab_size > arith__max_alphabet_size)
  error('Maximum alphabet size = %d < %d', ...
	arith__max_alphabet_size, ab_size);
end


if (skip==0)
  command = 'new_decoder';
else
  command = sprintf('new_decoder:s=%d', skip);
end

h.handler = arith__coder__gateway(command, filename, ab_size, buf);
h.filename = filename;
h.encoder = 0;
h.open = 1;
h.ab_size = ab_size;
