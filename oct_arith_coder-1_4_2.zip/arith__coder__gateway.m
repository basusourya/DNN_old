function y=arith__coder__gateway(what, varargin)
% ARITH_CODER           MEX File dispatcher
%
%      Synopsys:
%
%            H = ARITH_CODER('new_encoder', 'filename', n_symbols, [model])
%            H = ARITH_CODER('new_decoder', 'filename', n_symbols, [model])
%
%                ARITH_CODER('done', H)
%
%                ARITH_CODER('encode', H, SYMBOL)
%            S = ARITH_CODER('decode', H)
%            S = ARITH_CODER('decode', H, Nsymbols)
%
%            N = ARITH_CODER('bits', H)
%
%      Parameters:
%
%           VOID
%
%      Description:
%
%           This function is a low-level interface to a MEX
%           implementation of an arithmetic enc/decoder.  The
%           occasional user does not call this function directly,
%           but uses the methods of classes ARITHMETIC_ENCODER and 
%           ARITHMETIC_DECODER. 
%
%           The first parameter is always an "action", the other
%           parameters depend on the required "action".
%
%           If the action is "new_encoder" or "new_decoder" a new
%           enc/decoder is created and the handler H is returned.
%           "filename" is the file read (written) by the decoder
%           (by the encoder), "n_symbols" is the alphabet size and
%           the optional parameter "model" is currently ignored.
% 
%           If the action is "done" the enc/decoder with handler H
%           (and the corresponding I/O file) is closed.  
%
%           With action "encode" symbol SYMBOL (which must be an
%           integer value between 0 and N_SYMBOLS-1) is encoded.
%
%      Defaults:
%
%           NONE
%
%      See also: 
%
%           ARITHMETIC_DECODER, ARITHMETIC_ENCODER
%

%%
%% Default handling
%%

%
% Call parsing
%

%
% Default values
%

%%
%% True code
%%

%
% We need to register an atexit function in order to close nicely
% any output file which are still open when Octave/Matlab exits.
% In Matlab we use the mexAtExit() C function, while in Octave we
% exploit the Octave function atexit().
%
persistent atexit_registered

is_octave = exist('octave_config_info');

if (is_octave && isempty(atexit_registered))
  atexit('arith__cleanup');
  atexit_registered = 1;
end


if (exist('arith_coder_mex')==0)
  %
  % If the mex file does not exist, try to install it.  We need to 
  % move into the directory which contains this file.  First of
  % all, save the current directory in order to come back to it.
  %
  current_dir = pwd;

  %
  % Find out your own dir
  %
  my_dir = fileparts(which('arith__coder__gateway'));

  %
  % Change to your own directory
  %
  cd(my_dir);
  
  %
  % Compile the C code
  %
  if (is_octave)
    mex('-DIN_OCTAVE', 'arith_coder_mex.c', 'ac.c');
  else
    mex('arith_coder_mex.c',  'ac.c');
  end
  
  %
  % Back to the original dir
  %
  cd(current_dir);
end

%
% Yes, it is just this...
%
y=arith_coder_mex(what, varargin{:});