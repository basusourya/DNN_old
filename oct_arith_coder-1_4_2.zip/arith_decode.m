function y=arith_decode(decoder, N_symb)
% ARITH_DECODE           Brief description
%
%      Synopsys:
%
%            Y=ARITH_DECODE(DECODER, N_SYMB)
%
%      Parameters:
%
%           DECODER = Handler of an arithmetic decoder created with 
%           NEW_ARITHMETIC_DECODER
%
%           N_SYMB = Number of symbols to be decoded.
%
%      Description:
%
%           If N_SYMB is a scalar, extract N_SYMB symbols from the
%           bitstream given to the arithmetic decoder and return
%           the result as a column vector.  If N_SYMB is a vector,
%           extract prod(N_SYMB) and return the result as a matrix
%           with size()=N_SYMB.
%
%           If in the coded stream there are not enough
%           symbols the behaviour is undefined.  
%
%      Defaults:
%
%           N_SYMB = 1
%
%      See also: 
%
%           NEW_ARITHMETIC_DECODER
%

%%
%% Default handling
%%

%
% Call parsing
%

if (~isfield(decoder, 'encoder') || decoder.encoder)
  error('Not a decoder');
end

if (nargin < 2)
  N_symb =[1, 1];
end

%
% Default values
%

%%
%% True code
%%

if (length(N_symb)==1)
  N_symb = [N_symb, 1];
end

how_many = prod(N_symb);
tmp = arith__coder__gateway('decode', decoder.handler, how_many);
y = reshape(tmp, N_symb);
