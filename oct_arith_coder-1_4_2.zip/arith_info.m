function y=arith_info(h)
% ARITH_INFO           Brief description
%
%      Synopsys:
%
%            Y=ARITH_INFO(HANDLER)
%
%      Parameters:
%
%           VOID
%
%      Description:
%
%           NONE
%
%      Defaults:
%
%           NONE
%
%      See also: 
%
%           NONE
%

%%
%% Default handling
%%

%
% Call parsing
%

%
% Default values
%

arith__check_handler(h, 1);

%%
%% True code
%%
y = arith__coder__gateway('bits', h.handler);

