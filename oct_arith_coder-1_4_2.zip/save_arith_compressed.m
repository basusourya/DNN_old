function [info]=save_arith_compressed(x, filename, mode)
% SAVE_COMPRESSED           Brief description
%
%      Synopsys:
%
%            [INFO]=SAVE_ARITH_COMPRESSED(X, FILENAME, MODE)
%
%      Parameters:
%
%           X = Matrix of integer values
%
%      Description:
%
%           Save X to FILENAME compressing it by means of an
%           arithmetic encoder.  Matrix X can be reloaded with
%           function LOAD_ARITH_COMPRESSED.  
%
%           MODE specifies how the output file must be opened.  By
%           using MODE='a', the function will append the data to
%           FILENAME instead of rewriting it.  
%
%           Output parameter INFO is a struct containing several
%           informations about the saved data.  Currently it has
%           only the field "nbits" which holds the number of bits
%           used for X.
%
%      Defaults:
%
%           MODE = 'w'
%
%      See also: 
%
%           LOAD_ARITH_COMPRESSED
%

%%
%% Default handling
%%

%
% Call parsing
%

if (nargin < 3)
  mode = [];
end

%
% Default values
%

if (isempty(mode))
  mode = 'wb';
end

if (isempty(find(mode == 'b')))
  mode = [mode 'b'];
end

%%
%% True code
%%

%
% Formato del file:
%
%     * flag (uint8) da interpretarsi come segue
%
%         Bit 0:
%              0 = NDIM==2
%              1 = NDIM > 2
%
%         Bit 1-2:
%             00   P = 1 (P e` il numero di byte per dimensione,
%             01   P = 2 vedi + avanti)
%             10   P = 4 
%             11   Reserved
%
%         Bit 3:
%             0   Q = 1 (Q e` il numero di byte per la dim. alfabeto,
%             1   Q = 2 vedi + avanti)
%
%         Bit 4:
%             0   K_0 Assente 
%             1   K_0 Presente 
%
%         Bit 5-7: 
%              Reserved
%
%     * Se NDIM > 2, il # di dimensioni (uint8)
%
%     * Per ogni dimensione un intero senza segno a P byte
%
%     * Un intero con segno a Q byte per la dim. alfabeto
%
%     * Se Bit 4==1, un intero con segno a 2 byte per K_0
%


%
% Determina il numero di dimensioni della matrice di ingresso
%
dimen = size(x);

%
% Determina k0 e la dimensione dell'alfabeto
%
k0 = min(x(:));
x = x-k0;
ab_size = max(x(:))+1;


%
% Calcola il byte di flag
%
flag_ndim = (ndims(x) > 2);
flag_dims = vect2flag(dimen);
if (ab_size < 256)
  flag_ab_size = 0;
else
  flag_ab_size = 1;
end

flag_k0 = (k0 ~= 0);

flags = flag_ndim + 2*flag_dims + 8*flag_ab_size + 16*flag_k0;

%
% Apri il file di destinazione. Si noti il terzo parametro che
% richiede di salvare gli interi nel formato Big Endian (questo
% permette di portare i file salvati da un'architettura all'altra)
%
[fid,msg] = fopen(filename, mode, 'ieee-be');
if (fid < 0)
  error(['Could not open ' filename ' in output: ' msg]);
end

%
% Scrivi il flag
%
fwrite(fid, flags, 'uint8');

%
% Se NDIM > 2, scrivi il # di dimensioni
%
if (flag_ndim)
  fwrite(fid, length(dimen), 'uint8');
end

%
% Scrivi le dimensioni e i campioni quantizzati usando il numero di
% byte per valore opportuno
%
write_int_vec(fid, dimen, flag_dims);
write_int_vec(fid, ab_size, flag_ab_size);
if (flag_k0)
  fwrite(fid, k0, 'int16');
end
%
% Chiudi il file
%
fclose(fid);

%
% Comprimi il file e determina la sua dimensione
%
h = new_arithmetic_encoder(filename, ab_size, 'a');
arith_encode(h, x(:));
info.nbits = arith_info(h);
arith_close(h);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y=vect2flag(vec)

%
% Il '+1' serve perche' li considero con segno
%
nbit = nextpow2(max(abs(vec(:))))+1;

if (nbit <= 8)
  y=0;
elseif (nbit <= 16)
  y=1;
elseif (nbit <= 32)
  y=2;
else
  error('bbbb');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function write_int_vec(fid, vec, flag)

if (flag==0)
  fmt = 'uint8';
elseif (flag==1)
  fmt = 'uint16';
elseif (flag==2)  
  fmt = 'uint32';
else
  error('boh');
end

count=fwrite(fid, vec, fmt);
if (count < prod(size(vec)))
  error(sprintf('%d < %d', count, prod(size(vec))));
end
