function arith__check_handler(h, encod_flag, open)
% ARITH__CHECK_HANDLER           Do some checks on encoder/decoder handler
%
%      Synopsys:
%
%            ARITH__CHECK_HANDLER(H, [ENCOD_FLAG, [OPEN]])
%
%      Parameters:
%
%           VOID
%
%      Description:
%
%           Return 1 if H is a valid handler, 0 otherwise.  If
%           ENCOD_FLAG is not empty, check if H is an encoder
%           handler (ENCOD_FLAG==1) or a decoder handler
%           (ENCOD_FLAG==0).  If OPEN is not empty, check that H
%           refers to a still open coder/decoder.
%
%      Defaults:
%
%           ENCOD_FLAG = []
%           OPEN = 1
%
%      See also: 
%
%           NONE
%

%%
%% Default handling
%%

%
% Call parsing
%

%
% Default values
%

%%
%% True code
%%


if (nargin < 2)
  encod_flag=[];
end

if (nargin < 3)
  open = 1;
end

if (~isfield(h, 'handler'))
  error('Invalid handler');
end

if (~isempty(encod_flag) && encod_flag ~= h.encoder)
  if (encod_flag)
    error('Handler is not an encoder');
  else
    error('Handler is not a decoder');
  end
end

if (~isempty(open) && open ~= h.open)
  if (open)
    error('Handler is closed');
  else
    error('Handler is still open');
  end
end